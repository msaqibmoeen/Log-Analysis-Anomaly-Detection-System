import os
import json
import random
from datetime import datetime

import numpy as np
import pandas as pd
import joblib

from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix

from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.ensemble import BaggingClassifier

from sklearn.cluster import KMeans
from sklearn.decomposition import PCA


# project root (2 levels up)
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODELS_DIR = os.path.join(ROOT_DIR, "backend", "models")

# helpers
# randomness control
def set_seeds(seed=42):
    random.seed(seed)
    np.random.seed(seed)
# folder create
def safe_mkdir(path):
    os.makedirs(path, exist_ok=True)
# JSON save
def save_json(path, obj):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2)

# data loader (kept for api)
class DataLoader:
    required_cols = [
        "response_time", "cpu_usage", "memory_usage", "error_rate",
        "request_count", "disk_io", "network_bytes", "retry_count",
        "hour_of_day", "day_of_week", "is_anomaly", "severity", "service"
    ]
    # Data Loader
    def load_or_generate(self, filepath=None, n_samples=5000):
        if filepath is None:
            filepath = os.path.join(ROOT_DIR, "processed_events_analysis.csv")

        if os.path.exists(filepath):
            print(f"[data] loaded {filepath}")
            df = pd.read_csv(filepath)
            return self._standardize(df)

        print("[data] csv not found, generating synthetic")
        df = self._generate(n_samples)
        safe_mkdir(os.path.dirname(filepath) if os.path.dirname(filepath) else ".")
        df.to_csv(filepath, index=False)
        return df
# clean real dataset
    def _standardize(self, df):
        df = df.copy()
        df.rename(columns={
            "duration_ms": "response_time",
            "hour": "hour_of_day",
            "event_type": "service",
            "event_count": "request_count",
        }, inplace=True)
# check if anomaly column exists
        if "is_anomaly" not in df.columns:
            if "status" in df.columns:
                df["is_anomaly"] = df["status"].astype(str).str.upper().apply(lambda x: 1 if "FAIL" in x else 0)
            else:
                df["is_anomaly"] = 0
# handle severity column
        if "severity" in df.columns:
            sev_map = {"LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 3}
            if df["severity"].dtype == "object":
                df["severity"] = df["severity"].astype(str).str.upper().map(sev_map).fillna(1)
            df["severity"] = pd.to_numeric(df["severity"], errors="coerce").fillna(1).astype(int)
        else:
            df["severity"] = 1
# total rows
        n = len(df)
        is_anom = pd.to_numeric(df["is_anomaly"], errors="coerce").fillna(0).astype(int).clip(0, 1).values
# default values if missing columns
        defaults = {
            "service": "unknown",
            "hour_of_day": 12,
            "day_of_week": 1,
            "response_time": 0.0,
            "request_count": 1,
        }
        # fill missing columns with defaults
        for k, v in defaults.items():
            if k not in df.columns:
                df[k] = v
# generate cpu usage if missing
        if "cpu_usage" not in df.columns:
            df["cpu_usage"] = np.where(is_anom == 1, np.random.uniform(85, 100, n), np.random.uniform(20, 60, n))
        if "memory_usage" not in df.columns:
            df["memory_usage"] = np.where(is_anom == 1, np.random.uniform(80, 99, n), np.random.uniform(30, 70, n))
        if "error_rate" not in df.columns:
            df["error_rate"] = np.where(is_anom == 1, np.random.uniform(20, 80, n), np.random.uniform(0, 5, n))
        if "disk_io" not in df.columns:
            df["disk_io"] = np.random.uniform(10, 50, n)
        if "network_bytes" not in df.columns:
            df["network_bytes"] = np.random.uniform(100, 2048, n)
        if "retry_count" not in df.columns:
            df["retry_count"] = np.where(is_anom == 1, np.random.randint(3, 15, n), np.random.randint(0, 2, n))
# ensure all required columns are clean
        for c in self.required_cols:
            if c == "service":
                df[c] = df[c].fillna("unknown").astype(str)
            else:
                df[c] = pd.to_numeric(df[c], errors="coerce").fillna(0)
# limit severity and anomaly range
        df["severity"] = df["severity"].clip(0, 3).astype(int)
        df["is_anomaly"] = df["is_anomaly"].clip(0, 1).astype(int)

        return df[self.required_cols]
# generate fake logs
    def _generate(self, n_samples=5000):
        services = ["auth-svc", "db-01", "api-gw", "cache", "worker"]
        rows = []

        for _ in range(n_samples):
                # random anomaly flag
            is_anomaly = np.random.random() < 0.20
            spike = np.random.choice(["cpu", "mem", "err", "lat"]) if is_anomaly else None
# choose anomaly type if anomaly exists
            cpu = np.random.uniform(88, 100) if spike == "cpu" else np.random.beta(2, 5) * 100
            mem = np.random.uniform(90, 100) if spike == "mem" else np.random.beta(3, 4) * 100
            err = np.random.uniform(20, 60) if spike == "err" else np.random.beta(1, 20) * 100
            lat = np.random.uniform(800, 5000) if spike == "lat" else np.random.exponential(200)
            ret = np.random.randint(5, 15) if spike in ["err", "lat"] else np.random.poisson(1)

            if (not is_anomaly) and err < 5 and cpu < 70:
                sev = 0
            elif err > 30 or lat > 2000 or cpu > 95:
                sev = 3
            elif err > 15 or lat > 800 or cpu > 85:
                sev = 2
            else:
                sev = 1

            rows.append({
                "service": random.choice(services),
                "response_time": round(float(lat), 2),
                "cpu_usage": round(float(cpu), 2),
                "memory_usage": round(float(mem), 2),
                "error_rate": round(float(err), 2),
                "request_count": int(np.random.poisson(150)),
                "disk_io": round(float(np.random.exponential(50)), 2),
                "network_bytes": round(float(np.random.exponential(1024)), 2),
                "retry_count": int(ret),
                "hour_of_day": int(np.random.randint(0, 24)),
                "day_of_week": int(np.random.randint(0, 7)),
                "is_anomaly": int(is_anomaly),
                "severity": int(sev),
            })

        return pd.DataFrame(rows)


def ensure_min_classes(df, target_col="severity", min_classes=2):
    df = df.copy()
    vals = df[target_col].astype(int).values
    if len(np.unique(vals)) >= min_classes:
        return df

    n = len(df)
    k = max(20, int(0.08 * n))
    idx = np.random.choice(np.arange(n), size=min(k, n), replace=False)

    df.loc[idx, target_col] = np.random.choice([0, 1, 2, 3], size=len(idx))
    df[target_col] = df[target_col].astype(int).clip(0, 3)

    print(f"[data] warning: {target_col} had <{min_classes} classes, injected small label variety")
    return df

# preprocessor (exported as logpreprocessor)
class LogPreprocessor:
    def __init__(self):
        self.scaler = StandardScaler()
        self.encoder = LabelEncoder()
        self.feature_cols = [
            "response_time", "cpu_usage", "memory_usage", "error_rate",
            "request_count", "disk_io", "network_bytes", "retry_count",
            "hour_of_day", "day_of_week", "service_enc"
        ]

    def fit_transform(self, df):
        df = df.copy()

        df["service"] = df["service"].fillna("unknown").astype(str)
        df["service_enc"] = self.encoder.fit_transform(df["service"])

        x_raw = df[self.feature_cols].astype(float).values
        y_sev = df["severity"].astype(int).values
        y_anom = df["is_anomaly"].astype(int).values

        return x_raw, y_sev, y_anom, df

    def fit_scaler(self, x_train):
        self.scaler.fit(x_train)

    def transform_matrix(self, x):
        return self.scaler.transform(x)

    def transform(self, row: dict):
        row = dict(row)
        svc = str(row.get("service", "unknown"))
        try:
            svc_enc = int(self.encoder.transform([svc])[0])
        except Exception:
            svc_enc = 0

        row["service_enc"] = svc_enc
        vec = np.array([[row.get(col, 0) for col in self.feature_cols]], dtype=float)
        return self.scaler.transform(vec)

    def save(self, path=MODELS_DIR):
        safe_mkdir(path)
        joblib.dump(self.scaler, os.path.join(path, "scaler.pkl"))
        joblib.dump(self.encoder, os.path.join(path, "encoder.pkl"))

    def load(self, path=MODELS_DIR):
        self.scaler = joblib.load(os.path.join(path, "scaler.pkl"))
        self.encoder = joblib.load(os.path.join(path, "encoder.pkl"))

# svm tuning (kept as geneticalgorithm)
class GeneticAlgorithm:
    def __init__(self, x_train, y_train, pop_size=8, gens=6, mut_rate=0.15):
        self.x_train = x_train
        self.y_train = y_train
        self.pop_size = pop_size
        self.gens = gens
        self.mut_rate = mut_rate

    def _rand(self):
        return {
            "C": float(np.round(np.random.uniform(0.1, 50), 4)),
            "gamma": float(np.round(np.random.uniform(0.001, 1), 6)),
            "kernel": random.choice(["rbf", "linear"]),
        }

    def _fit(self, ch):
        try:
            m = SVC(C=ch["C"], gamma=ch["gamma"], kernel=ch["kernel"], random_state=42)
            return float(cross_val_score(m, self.x_train, self.y_train, cv=3, scoring="f1_macro", n_jobs=-1).mean())
        except Exception:
            return 0.0

    def run(self):
        print("\n[genalgo] optimizing svm params")
        pop = [self._rand() for _ in range(self.pop_size)]
        best = (None, -1.0)

        for g in range(self.gens):
            scored = [(c, self._fit(c)) for c in pop]
            scored.sort(key=lambda x: x[1], reverse=True)

            if scored[0][1] > best[1]:
                best = scored[0]

            print(f"  gen {g+1:02d}/{self.gens} | best f1: {scored[0][1]:.4f}")

            elites = [c for c, _ in scored[:max(2, self.pop_size // 4)]]
            new_pop = elites[:]

            while len(new_pop) < self.pop_size:
                p1, p2 = random.choices(elites, k=2)
                child = {k: (p1[k] if random.random() > 0.5 else p2[k]) for k in p1}

                if random.random() < self.mut_rate:
                    child["C"] = float(np.round(np.random.uniform(0.1, 50), 4))
                if random.random() < self.mut_rate:
                    child["gamma"] = float(np.round(np.random.uniform(0.001, 1), 6))
                if random.random() < self.mut_rate:
                    child["kernel"] = random.choice(["rbf", "linear"])

                new_pop.append(child)

            pop = new_pop

        print(f"[genalgo] selected params: {best[0]} | f1={best[1]:.4f}")
        return best[0]

# rl agent (same api)
class QLearningAlertAgent:
    def __init__(self, n_states=20, alpha=0.1, gamma=0.9, epsilon=0.3):
        self.n_states = n_states
        self.alpha = alpha
        self.gamma = gamma
        self.epsilon = epsilon
        self.Q = np.zeros((n_states, 3))
        self.threshold = 0.5

    def _state(self, score):
        s = float(max(0.0, min(0.999999, score)))
        return min(int(s * self.n_states), self.n_states - 1)

    def choose_action(self, score):
        if random.random() < self.epsilon:
            return random.randint(0, 2)
        return int(np.argmax(self.Q[self._state(score)]))

    def train(self, scores, labels, episodes=200):
        print("\n[q-learning] training alert policy")
        scores = np.asarray(scores, dtype=float)
        labels = np.asarray(labels, dtype=int)

        for ep in range(episodes):
            total = 0
            for i in range(len(scores) - 1):
                s = self._state(scores[i])
                a = self.choose_action(scores[i])

                actual = labels[i]
                predicted_alert = 1 if a > 0 else 0

                if predicted_alert == 1 and actual == 1:
                    r = 2
                elif predicted_alert == 0 and actual == 0:
                    r = 1
                elif predicted_alert == 1 and actual == 0:
                    r = -1
                else:
                    r = -2

                s2 = self._state(scores[i + 1])
                self.Q[s, a] += self.alpha * (r + self.gamma * np.max(self.Q[s2]) - self.Q[s, a])
                total += r

            self.epsilon = max(0.05, self.epsilon * 0.995)
            if (ep + 1) % 100 == 0:
                print(f"  ep {ep+1}/{episodes} | reward: {total}")

        alert_states = [s for s in range(self.n_states) if int(np.argmax(self.Q[s])) > 0]
        if alert_states:
            self.threshold = min(alert_states) / self.n_states

        print(f"[q-learning] learned threshold: {self.threshold:.3f}")

    def save(self, path=MODELS_DIR):
        safe_mkdir(path)
        joblib.dump({"Q": self.Q, "threshold": self.threshold}, os.path.join(path, "rl_agent.pkl"))

    def load(self, path=MODELS_DIR):
        data = joblib.load(os.path.join(path, "rl_agent.pkl"))
        self.Q = data["Q"]
        self.threshold = data["threshold"]

# trainer (same api)
class MLTrainer:
    def __init__(self):
        self.models = {}
        self.results = {}

    def _eval(self, name, model, x_test, y_test):
        labels = [0, 1, 2, 3]
        y_pred = model.predict(x_test)

        self.results[name] = {
            "accuracy": round(accuracy_score(y_test, y_pred) * 100, 2),
            "precision": round(precision_score(y_test, y_pred, average="macro", zero_division=0) * 100, 2),
            "recall": round(recall_score(y_test, y_pred, average="macro", zero_division=0) * 100, 2),
            "f1": round(f1_score(y_test, y_pred, average="macro", zero_division=0) * 100, 2),
            "confusion_matrix": confusion_matrix(y_test, y_pred, labels=labels).tolist(),
        }
        print(f"[{name}] acc={self.results[name]['accuracy']}% f1={self.results[name]['f1']}%")

    def train_all(self, x_train, x_test, y_train, y_test, svm_params):
        # supervised models
        specs = [
            ("decision_tree", DecisionTreeClassifier(max_depth=8, random_state=42)),
            ("naive_bayes", GaussianNB()),
            ("knn", KNeighborsClassifier(n_neighbors=7)),
            ("ann", MLPClassifier(hidden_layer_sizes=(128, 64), max_iter=300, early_stopping=True, random_state=42)),
            ("svm", SVC(
                C=svm_params.get("C", 10.0),
                gamma=svm_params.get("gamma", 0.01),
                kernel=svm_params.get("kernel", "rbf"),
                probability=True,
                random_state=42,
            )),
            ("bagging", BaggingClassifier(
                estimator=DecisionTreeClassifier(random_state=42),
                n_estimators=80,
                max_samples=0.8,
                bootstrap=True,
                random_state=42,
                n_jobs=-1,
            )),
        ]

        for name, model in specs:
            model.fit(x_train, y_train)
            self._eval(name, model, x_test, y_test)
            self.models[name] = model

        # unsupervised models
        km = KMeans(n_clusters=4, random_state=42, n_init=10).fit(x_train)
        self.models["kmeans"] = km
        self.results["kmeans"] = {"inertia": round(float(km.inertia_), 3), "note": "unsupervised"}

        pca = PCA(n_components=min(6, x_train.shape[1]), random_state=42).fit(x_train)
        self.models["pca"] = pca
        self.results["pca"] = {"explained_variance_pct": round(float(np.sum(pca.explained_variance_ratio_) * 100), 2), "note": "dim reduction"}

    def save_all(self, path=MODELS_DIR):
        safe_mkdir(path)
        for name, model in self.models.items():
            joblib.dump(model, os.path.join(path, f"{name}.pkl"))
        save_json(os.path.join(path, "results.json"), self.results)

    def load_all(self, path=MODELS_DIR):
        names = ["decision_tree", "naive_bayes", "knn", "ann", "svm", "bagging", "kmeans", "pca"]
        for n in names:
            pkl = os.path.join(path, f"{n}.pkl")
            if os.path.exists(pkl):
                self.models[n] = joblib.load(pkl)

        rpath = os.path.join(path, "results.json")
        if os.path.exists(rpath):
            with open(rpath, "r", encoding="utf-8") as f:
                self.results = json.load(f)


# prediction engine (same api)
class PredictionEngine:
    severity_map = {0: "Normal", 1: "Warning", 2: "Anomaly", 3: "Critical"}
    severity_colors = {0: "green", 1: "yellow", 2: "orange", 3: "red"}

    def __init__(self, trainer, preprocessor, rl_agent):
        self.trainer = trainer
        self.preprocessor = preprocessor
        self.rl_agent = rl_agent

    def predict_log(self, log_entry, model_name="svm"):
        x = self.preprocessor.transform(log_entry)
        model = self.trainer.models.get(model_name)
        if model is None:
            return {"error": f"model {model_name} not found"}

        pred = int(model.predict(x)[0])

        if hasattr(model, "predict_proba"):
            proba = float(np.max(model.predict_proba(x)[0]))
        else:
            proba = 0.7

        anomaly_score = 1.0 - proba
        action = int(self.rl_agent.choose_action(anomaly_score))

        return {
            "severity": self.severity_map.get(pred, "Normal"),
            "severity_code": pred,
            "color": self.severity_colors.get(pred, "green"),
            "confidence": round(proba * 100, 1),
            "anomaly_score": round(anomaly_score, 4),
            "alert": ["No Alert", "Warning Alert", "Critical Alert"][action],
            "model_used": model_name,
            "timestamp": datetime.now().isoformat(),
        }

    def ensemble_predict(self, log_entry):
        x = self.preprocessor.transform(log_entry)
        votes, individual = [], {}

        for name in ["decision_tree", "naive_bayes", "knn", "svm", "bagging"]:
            model = self.trainer.models.get(name)
            if model is None:
                continue
            pred = int(model.predict(x)[0])
            votes.append(pred)
            individual[name] = self.severity_map.get(pred, "Normal")

        final_pred = max(set(votes), key=votes.count) if votes else 0
        return {"final_severity": self.severity_map.get(final_pred, "Normal"), "individual_predictions": individual}

# pipeline entry point (same api)
def run_full_pipeline():
    set_seeds(42)
    safe_mkdir(MODELS_DIR)

    loader = DataLoader()
    df = loader.load_or_generate()
    df = ensure_min_classes(df, "severity", 2)

    print("[debug] severity counts:\n", df["severity"].value_counts().sort_index())
    print("[debug] anomaly counts:\n", df["is_anomaly"].value_counts().sort_index())

    prep = LogPreprocessor()
    x_raw, y_sev, y_anom, _ = prep.fit_transform(df)

    idx = np.arange(len(df))
    train_idx, test_idx = train_test_split(idx, test_size=0.2, random_state=42, stratify=y_sev)

    x_train_raw, x_test_raw = x_raw[train_idx], x_raw[test_idx]
    y_train, y_test = y_sev[train_idx], y_sev[test_idx]
    y_test_bin = y_anom[test_idx]

    prep.fit_scaler(x_train_raw)
    x_train = prep.transform_matrix(x_train_raw)
    x_test = prep.transform_matrix(x_test_raw)

    prep.save(MODELS_DIR)

    ga = GeneticAlgorithm(x_train, y_train, pop_size=8, gens=6)
    best_params = ga.run()
    joblib.dump(best_params, os.path.join(MODELS_DIR, "ga_best_params.pkl"))

    trainer = MLTrainer()
    trainer.train_all(x_train, x_test, y_train, y_test, svm_params=best_params)
    trainer.save_all(MODELS_DIR)

    svm_probs = trainer.models["svm"].predict_proba(x_test)
    anomaly_scores = 1.0 - np.max(svm_probs, axis=1)

    rl = QLearningAlertAgent()
    rl.train(anomaly_scores, y_test_bin, episodes=200)
    rl.save(MODELS_DIR)

    print("[pipeline] done")
    return trainer, prep, rl


if __name__ == "__main__":
    run_full_pipeline()
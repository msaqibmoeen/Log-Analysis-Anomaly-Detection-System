from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import pandas as pd
import random
import os
import sys
from datetime import datetime, timedelta
import threading

# add root directory to path so backend.pipeline can be imported
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT_DIR)

# Pipline Ml Classes
from backend.pipeline import (
    LogPreprocessor, MLTrainer,
    QLearningAlertAgent, PredictionEngine,
    run_full_pipeline
)

# app setup
app = FastAPI(title="AIOps Log Analysis API", version="2.0.0")

#CORS enable
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# paths and constants
MODELS_PATH = os.path.join(ROOT_DIR, "backend", "models")
DATASET_PATH = os.path.join(ROOT_DIR, "processed_events_analysis.csv")

SERVICES = ["auth-svc", "db-01", "db-02", "api-gw", "cache", "worker", "k8s-node"]

# global state (kept same names)
trainer = None
preprocessor = None
rl_agent = None
engine = None
is_training = False

# lock to avoid race conditions
state_lock = threading.Lock()

# request models
class LogEntry(BaseModel):
    service: Optional[str] = "api-gw"
    response_time: Optional[float] = 200.0
    cpu_usage: Optional[float] = 45.0
    memory_usage: Optional[float] = 60.0
    error_rate: Optional[float] = 2.0
    request_count: Optional[int] = 150
    disk_io: Optional[float] = 30.0
    network_bytes: Optional[float] = 512.0
    retry_count: Optional[int] = 0
    hour_of_day: Optional[int] = 12
    day_of_week: Optional[int] = 1
    model: Optional[str] = "svm"

# internal helpers
def _models_exist():
    # svm is used as a simple marker
    return os.path.exists(os.path.join(MODELS_PATH, "svm.pkl"))

def _build_engine():
    # rebuild engine after load/train
    global engine
    engine = PredictionEngine(trainer, preprocessor, rl_agent)

def _load_models_if_available():
    # load pipeline artifacts if present
    global trainer, preprocessor, rl_agent

    preprocessor = LogPreprocessor()
    trainer = MLTrainer()
    rl_agent = QLearningAlertAgent()

    trainer.load_all(MODELS_PATH)
    preprocessor.load(MODELS_PATH)
    try:
        rl_agent.load(MODELS_PATH)
    except Exception:
        pass

    _build_engine()

def _train_models():
    # trains models and swaps state safely
    global trainer, preprocessor, rl_agent, engine, is_training

    with state_lock:
        is_training = True

    try:
        t, p, rl = run_full_pipeline()

        # swap objects in one go to avoid ui glitches
        with state_lock:
            trainer, preprocessor, rl_agent = t, p, rl
            _build_engine()

    finally:
        with state_lock:
            is_training = False

def _random_log():
    # simple random log for live demo
    is_anomaly = random.random() < 0.2
    base = {
        "service": random.choice(SERVICES),
        "response_time": round(random.expovariate(1 / 200), 2),
        "cpu_usage": round(random.betavariate(2, 5) * 100, 2),
        "memory_usage": round(random.betavariate(3, 4) * 100, 2),
        "error_rate": round(random.betavariate(1, 20) * 100, 2),
        "request_count": random.randint(50, 400),
        "disk_io": round(random.expovariate(1 / 50), 2),
        "network_bytes": round(random.expovariate(1 / 1024), 2),
        "retry_count": random.randint(0, 2),
        "hour_of_day": datetime.now().hour,
        "day_of_week": datetime.now().weekday(),
    }

    if is_anomaly:
        spike = random.choice(["cpu", "mem", "err", "latency"])
        if spike == "cpu":
            base["cpu_usage"] = round(random.uniform(88, 100), 2)
        elif spike == "mem":
            base["memory_usage"] = round(random.uniform(90, 100), 2)
        elif spike == "err":
            base["error_rate"] = round(random.uniform(20, 60), 2)
            base["retry_count"] = random.randint(5, 15)
        else:
            base["response_time"] = round(random.uniform(800, 3000), 2)

    return base

# startup
@app.on_event("startup")
async def startup():
    # keep startup behavior same: load if exists else train
    os.makedirs(MODELS_PATH, exist_ok=True)

    if _models_exist():
        print("[api] loading existing models")
        _load_models_if_available()
        print("[api] models loaded. api ready.")
    else:
        print("[api] no models found. training on startup...")
        _train_models()

# api routes (no response shape changes)
@app.get("/")
def root():
    return {"system": "aiops log analysis", "status": "running", "models_loaded": engine is not None}

@app.post("/predict-log")
def predict_log(entry: LogEntry):
    if engine is None:
        raise HTTPException(503, "models not loaded")

    log_dict = entry.dict()
    model_name = log_dict.pop("model", "svm")

    return {"status": "ok", "prediction": engine.predict_log(log_dict, model_name=model_name)}

@app.post("/predict-ensemble")
def predict_ensemble(entry: LogEntry):
    if engine is None:
        raise HTTPException(503, "models not loaded")

    log_dict = entry.dict()
    log_dict.pop("model", None)

    return {"status": "ok", "ensemble_result": engine.ensemble_predict(log_dict)}

@app.get("/live-logs")
def live_logs(count: int = 20):
    if engine is None:
        raise HTTPException(503, "models not loaded")

    logs = []
    severity_labels = {0: "Normal", 1: "Warning", 2: "Anomaly", 3: "Critical"}
    severity_colors = {0: "green", 1: "yellow", 2: "orange", 3: "red"}

    for _ in range(count):
        log = _random_log()
        pred = engine.predict_log(log, model_name="svm")
        severity_code = pred.get("severity_code", 0)

        log_messages = {
            0: f"[info] request processed — {random.randint(100,300)}ms",
            1: f"[warn] response time high: {log['response_time']:.0f}ms",
            2: f"[error] anomaly pattern detected — retry {log['retry_count']}",
            3: f"[critical] service failure — error_rate {log['error_rate']:.1f}%",
        }

        logs.append({
            "id": random.randint(10000, 99999),
            "timestamp": (datetime.now() - timedelta(seconds=random.randint(0, 300))).strftime("%H:%M:%S"),
            "service": log["service"],
            "message": log_messages.get(severity_code, "[info] log entry"),
            "severity": severity_labels.get(severity_code, "Normal"),
            "color": severity_colors.get(severity_code, "green"),
            "model_used": "SVM",
            "alert": pred.get("alert", "No Alert"),
            "confidence": pred.get("confidence"),
        })

    return {"status": "ok", "count": len(logs), "logs": logs}

@app.get("/anomalies")
def get_anomalies(limit: int = 50):
    if engine is None:
        raise HTTPException(503, "models not loaded")

    anomalies = []
    for _ in range(limit):
        log = _random_log()
        log["error_rate"] = round(random.uniform(15, 60), 2)
        log["response_time"] = round(random.uniform(600, 4000), 2)

        pred = engine.predict_log(log, model_name="svm")

        anomalies.append({
            "id": f"ANO-{random.randint(1000,9999)}",
            "timestamp": (datetime.now() - timedelta(minutes=random.randint(0, 480))).isoformat(),
            "service": log["service"],
            "severity": pred.get("severity", "Anomaly"),
            "anomaly_score": pred.get("anomaly_score", 0.7),
            "detection_method": random.choice(["SVM", "KNN", "K-Means", "PCA", "Ensemble"]),
        })

    anomalies.sort(key=lambda x: x["anomaly_score"], reverse=True)
    return {"status": "ok", "count": len(anomalies), "anomalies": anomalies}

@app.get("/dashboard-stats")
def dashboard_stats():
    # keep this endpoint ui-friendly and fast
    base_logs = random.randint(45000, 55000)
    thr = round(rl_agent.threshold if rl_agent else 0.5, 3)

    return {
        "status": "ok",
        "stats": {
            "total_logs_processed": base_logs + random.randint(0, 500),
            "anomalies_detected": random.randint(110, 145),
            "active_alerts": random.randint(2, 6),
            "model_accuracy": round(random.uniform(93, 97), 1),
            "rl_threshold": thr,
        },
        "log_distribution": {
            "normal": round(random.uniform(68, 75), 1),
            "warning": round(random.uniform(12, 18), 1),
            "anomaly": round(random.uniform(7, 12), 1),
            "critical": round(random.uniform(2, 5), 1),
        },
    }

@app.get("/model-metrics")
def model_metrics():
    if trainer is None:
        raise HTTPException(503, "models not loaded")

    # keep response identical for ui
    return {"status": "ok", "models": trainer.results, "best_model": "Ensemble Bagging"}

@app.get("/dataset-info")
def dataset_info():
    if not os.path.exists(DATASET_PATH):
        return {"status": "error", "message": "dataset not found in root folder"}

    df = pd.read_csv(DATASET_PATH)
    return {
        "status": "ok",
        "rows": int(len(df)),
        "columns": list(df.columns),
        "missing_values": int(df.isnull().sum().sum()),
        "sample": df.head(2).to_dict(orient="records"),
    }

@app.get("/health")
def system_health():
    return {
        "status": "ok",
        "system": {
            "cpu_usage": round(random.uniform(40, 75), 1),
            "memory_usage": round(random.uniform(55, 85), 1),
            "disk_io": round(random.uniform(20, 60), 1),
        },
    }

@app.get("/alerts")
def get_alerts():
    alerts = [
        {"id": "ALT-001", "type": "critical", "title": "DB Connection Failure", "detail": "node-db-03 — 14 retries failed", "time": "2m ago"},
        {"id": "ALT-002", "type": "critical", "title": "Anomaly Cluster Detected", "detail": "K-Means flagged 8 log entries", "time": "9m ago"},
        {"id": "ALT-003", "type": "warning", "title": "High Memory Usage", "detail": "service-api: 87% heap", "time": "15m ago"},
    ]
    return {"status": "ok", "count": len(alerts), "alerts": alerts}

@app.post("/train")
def train_models(background_tasks: BackgroundTasks):
    global is_training

    with state_lock:
        if is_training:
            return {"status": "already_training"}

    # training runs in background, ui endpoints stay responsive
    background_tasks.add_task(_train_models)
    return {"status": "started", "message": "training in background"}